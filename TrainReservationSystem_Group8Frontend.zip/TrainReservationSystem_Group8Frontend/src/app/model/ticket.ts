export class Ticket {
    

}
