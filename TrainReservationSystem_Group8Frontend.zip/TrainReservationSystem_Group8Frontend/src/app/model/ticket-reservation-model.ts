export class TicketReservationModel {
        [x: string]: any;
   
        trainId:number;
      //  journeyType:string;
        from:string;
        to:string;
        departDate:string;
        returnDate:string;
       // adultPassenger:number;
       // childrenPassenger:number;
        travelClass:string;
        trainName:string;

    
    
    
    
}
