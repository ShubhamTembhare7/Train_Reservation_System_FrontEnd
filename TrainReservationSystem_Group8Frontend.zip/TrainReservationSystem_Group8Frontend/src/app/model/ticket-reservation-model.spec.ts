import { TicketReservationModel } from './ticket-reservation-model';

describe('TicketReservationModel', () => {
  it('should create an instance', () => {
    expect(new TicketReservationModel()).toBeTruthy();
  });
});
