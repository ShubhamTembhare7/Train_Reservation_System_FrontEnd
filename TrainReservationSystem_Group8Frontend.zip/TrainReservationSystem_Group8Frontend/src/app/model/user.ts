export class User {
      id:number;
      firstName:string;
      lastName:string;
      email:string;
      userName:string;
      password:string;
      mobileNumber:number;
      dateOfBirth:string;
      gender:string;
      
}
